﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data;
using System.Data.OleDb;

namespace test_veri
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        public OleDbConnection con;
        int rowindex;
        int id;
        public void baglan()
        {
            string con_string = "Provider=Microsoft.ACE.OLEDB.12.0; Data Source=..\\veri\\veri.mdb; Persist Security Info=False;";
            con = new OleDbConnection(con_string);
            con.Open();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            GridViewDoldur();
        }
        void GridViewDoldur()
        {
            // soru 1
            da.Fill(dt);


            baglan();
            // soru 2 
        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
            {


                DataTable dt = new DataTable();
            da.Fill(dt);

            dataGridView1.DataSource = dt;
            dataGridView1.Refresh();
        }
        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            rowindex = e.RowIndex;
            DataGridViewRow row = dataGridView1.Rows[rowindex];
            id = Convert.ToInt32(row.Cells[0].Value);
            txt_kul_adi.Text = row.Cells[1].Value.ToString();
            txt_sifre.Text = row.Cells[2].Value.ToString();
        }

        private void btn_guncelle_Click(object sender, EventArgs e)
        {
            string sql = "UPDATE KULLANICI SET K_ADI=@p1, SIFRE=@p2 WHERE ID=@p3";
            baglan();
            OleDbCommand komut = new OleDbCommand(sql, con);
            komut.Parameters.AddWithValue("@p1", txt_kul_adi.Text);
            komut.Parameters.AddWithValue("@p2", txt_sifre.Text);
            komut.Parameters.AddWithValue("@p3", id);
            //soru 3
            string sql = "DELETE FROM KULLANICI WHERE ID=@ID";

                GridViewDoldur();
            MessageBox.Show("Güncelleme Başarılı", "Kayıt", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void btn_yeni_kayit_Click(object sender, EventArgs e)
        {
            // soru4
            OleDbCommand komut = new OleDbCommand(sql, con);

            }

            private void btn_kaydet_Click(object sender, EventArgs e)
        {
            string sql = "INSERT INTO KULLANICI(K_ADI, SIFRE) VALUES(@K_ADI,@SIFRE)";
            baglan();
            OleDbCommand komut = new OleDbCommand(sql, con);
            komut.Parameters.AddWithValue("@K_ADI", txt_kul_adi.Text);
            komut.Parameters.AddWithValue("@SIFRE", txt_sifre.Text);
            komut.ExecuteNonQuery();
            con.Close();
            GridViewDoldur();
            MessageBox.Show("Kayıt Başarılı", "Kayıt", MessageBoxButtons.OK, MessageBoxIcon.Information);
            
        }

        private void btn_sil_Click(object sender, EventArgs e)
        {
            string sql = "DELETE FROM KULLANICI WHERE ID=@ID";
            baglan();
            OleDbCommand komut = new OleDbCommand(sql, con);
            //soru5
            OleDbCommand komut = new OleDbCommand(sql, con);
            }
        }

        komut.ExecuteNonQuery();
            con.Close();
            GridViewDoldur();
            txt_kul_adi.Text = "";
            txt_sifre.Text = "";
            MessageBox.Show("Silme Başarılı", "Kayıt", MessageBoxButtons.OK, MessageBoxIcon.Information); ;
        }

    }
}
